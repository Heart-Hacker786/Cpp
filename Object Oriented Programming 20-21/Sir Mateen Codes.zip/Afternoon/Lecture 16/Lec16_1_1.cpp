#include "List.h"

int main(){
	List list1(5);
	list1.show();
	List list2;
	list2.show();
	return 0;
}
