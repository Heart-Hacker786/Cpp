#include <iostream>

using namespace std;

int main(){
	cout << "First Program in OOP\n";
}
