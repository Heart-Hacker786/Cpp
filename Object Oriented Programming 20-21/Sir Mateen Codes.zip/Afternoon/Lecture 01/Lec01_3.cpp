#include <iostream>

using namespace std;

int main(){
	cout << "First Line\n";
	cout << "Second Line\n";
	cout << "Third Line\n";
	return 0;
}
