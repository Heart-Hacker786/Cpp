#include <iostream>

using namespace std;

int main(){
	int price = 100;
	cout << "Price=" ;
	cout << price ;
	cout << '\n';
	return 0;
}
