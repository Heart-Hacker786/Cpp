#include <iostream>

using namespace std;

int main(){
	int x;
	for (x=1;x<=20;x++)
		cout << "X:" << x << '\n';
	return 0;
}
