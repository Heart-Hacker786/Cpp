#include <iostream>

using namespace std;

int main(){
	cout << "First line\nSecond line\n" << "Third line\n" ;
	return 0;
}
