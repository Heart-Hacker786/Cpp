#include <iostream>

using namespace std;

int main(){
	int price = 100;
	cout << "Price:" << price << '\n' ;
	return 0;
}
