#include <iostream>

using namespace std;

int main(){
	cout << "First line\n" << "Second line\n" << "Third line\n" ;
	return 0;
}
