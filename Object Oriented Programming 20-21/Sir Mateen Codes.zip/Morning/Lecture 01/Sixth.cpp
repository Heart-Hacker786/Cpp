#include <iostream>

using namespace std;

int main(){
	int price = 100;
	cout << "Price:" << price << '\n' ;

	printf ("Price:%d\n", price);
	
	return 0;
}

	/*cout << "Price:";
	cout << price;
	cout << '\n';*/
