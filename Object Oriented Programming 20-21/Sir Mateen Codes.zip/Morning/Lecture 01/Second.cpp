#include <iostream>

using namespace std;

int main(){
	cout << "Bismillah, today is our first oop class\n" ;
	cout << "This is second line\n" ;
	cout << "This is third line\n" ;
	return 0;
}
