#include <iostream>

using namespace std;

int main(){
	cout "Bismillah, today is our first oop class\n" ;
	return 0;
}
