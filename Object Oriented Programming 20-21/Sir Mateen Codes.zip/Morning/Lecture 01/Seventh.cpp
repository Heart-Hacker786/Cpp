#include <iostream>

using namespace std;

int main(){
	int i=1;
	for (i=1;i<=20;i++)
		cout << i << '\n' ;


	return 0;
}

